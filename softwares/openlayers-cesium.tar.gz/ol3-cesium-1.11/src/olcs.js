goog.provide('olcs.obj');


/**
 * Cast to object.
 * @param {Object} param
 * @return {Object}
 */
olcs.obj = function(param) {
  return param;
};
