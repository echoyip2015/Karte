Extending the OL3-Cesium library classes requires both the library code and
the extension code to be compiled together using the Closure compiler.

You may want to put your extension code in this directory so that it is
automatically compiled together with the library.
